import { createContext, useContext, useState, ReactNode } from 'react';

interface AudioContextType {
  audioEnabled: boolean;
  toggleAudio: () => void;
  playUISound: (type: 'hover' | 'select' | 'toggle') => void;
}

const AudioContext = createContext<AudioContextType>({
  audioEnabled: false,
  toggleAudio: () => {},
  playUISound: () => {}
});

export function AudioProvider({ children }: { children: ReactNode }) {
  const [audioEnabled, setAudioEnabled] = useState(false);

  const toggleAudio = () => {
    setAudioEnabled(!audioEnabled);
  };

  const playUISound = (type: 'hover' | 'select' | 'toggle') => {
    // Simplified version - no actual sound playback for now
    console.log(`Playing ${type} sound`);
  };

  return (
    <AudioContext.Provider value={{ audioEnabled, toggleAudio, playUISound }}>
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  return useContext(AudioContext);
}
