import { createContext, useContext, useState, ReactNode } from 'react';

type Section = 'blueprint' | 'calendar' | 'tasks' | 'archives' | 'settings';

interface NavigationContextType {
  activeSection: Section;
  setActiveSection: (section: Section) => void;
}

const NavigationContext = createContext<NavigationContextType>({
  activeSection: 'blueprint',
  setActiveSection: () => {}
});

export function NavigationProvider({ children }: { children: ReactNode }) {
  const [activeSection, setActiveSection] = useState<Section>('blueprint');

  return (
    <NavigationContext.Provider value={{ activeSection, setActiveSection }}>
      {children}
    </NavigationContext.Provider>
  );
}

export function useNavigation() {
  return useContext(NavigationContext);
}
