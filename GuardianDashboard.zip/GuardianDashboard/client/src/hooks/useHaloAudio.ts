import { useCallback } from 'react';
import { useAudio } from '../context/AudioContext';

interface UseHaloAudioReturn {
  isMuted: boolean;
  toggleMute: () => void;
  playHoverSound: () => void;
  playSelectSound: () => void;
  playToggleSound: () => void;
}

export function useHaloAudio(): UseHaloAudioReturn {
  const { audioEnabled, toggleAudio, playUISound } = useAudio();
  
  const playHoverSound = useCallback(() => {
    playUISound('hover');
  }, [playUISound]);
  
  const playSelectSound = useCallback(() => {
    playUISound('select');
  }, [playUISound]);
  
  const playToggleSound = useCallback(() => {
    playUISound('toggle');
  }, [playUISound]);
  
  return {
    isMuted: !audioEnabled,
    toggleMute: toggleAudio,
    playHoverSound,
    playSelectSound,
    playToggleSound
  };
}
