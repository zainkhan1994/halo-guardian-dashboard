import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { AudioProvider } from "./context/AudioContext";
import { NavigationProvider } from "./context/NavigationContext";

createRoot(document.getElementById("root")!).render(
  <NavigationProvider>
    <AudioProvider>
      <App />
    </AudioProvider>
  </NavigationProvider>
);
