import { motion } from "framer-motion";
import { useState } from "react";
import { useHaloAudio } from "@/hooks/useHaloAudio";

interface ToggleSetting {
  id: string;
  label: string;
  enabled: boolean;
}

interface SliderSetting {
  id: string;
  label: string;
  value: number;
  min: number;
  max: number;
}

interface RadioSetting {
  id: string;
  label: string;
  options: string[];
  selected: string;
}

export function SettingsSection() {
  const { playHoverSound, playToggleSound, playSelectSound } = useHaloAudio();
  
  // Display settings
  const [darkMode, setDarkMode] = useState(true);
  const [interfaceOpacity, setInterfaceOpacity] = useState(60);
  const [ambientEffects, setAmbientEffects] = useState("LOW");
  
  // Audio settings
  const [audioToggles, setAudioToggles] = useState<ToggleSetting[]>([
    { id: 'ui-sfx', label: 'UI Sound Effects', enabled: true },
    { id: 'ambient-audio', label: 'Ambient Audio', enabled: true }
  ]);
  const [audioVolume, setAudioVolume] = useState(40);
  
  // Notification settings
  const [notificationToggles, setNotificationToggles] = useState<ToggleSetting[]>([
    { id: 'task-reminders', label: 'Task Reminders', enabled: true },
    { id: 'calendar-alerts', label: 'Calendar Alerts', enabled: true },
    { id: 'system-updates', label: 'System Updates', enabled: true }
  ]);
  
  const toggleSetting = (id: string, settingType: 'audio' | 'notifications') => {
    playToggleSound();
    
    if (settingType === 'audio') {
      setAudioToggles(audioToggles.map(setting => 
        setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
      ));
    } else {
      setNotificationToggles(notificationToggles.map(setting => 
        setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
      ));
    }
  };
  
  const handleAmbientEffectChange = (level: string) => {
    playSelectSound();
    setAmbientEffects(level);
  };
  
  return (
    <motion.div 
      className="holographic-panel rounded-lg p-5 h-full overflow-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-xl font-bank-gothic text-forerunner-blue border-b border-forerunner-blue/40 pb-2 mb-6 flex items-center">
        <i className="fas fa-cog mr-3"></i>
        <span>SYSTEM SETTINGS</span>
      </div>
      
      <div className="h-[calc(100%-60px)] overflow-auto pb-4">
        {/* User profile */}
        <motion.div 
          className="bg-forerunner-dark-blue/40 p-4 rounded-lg mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h3 className="font-bank-gothic text-forerunner-blue mb-3">USER PROFILE</h3>
          
          <div className="flex items-center">
            <div className="w-16 h-16 rounded-full bg-forerunner-blue/20 border-2 border-forerunner-blue flex items-center justify-center mr-4">
              <i className="fas fa-user text-forerunner-blue text-xl"></i>
            </div>
            <div>
              <div className="font-bank-gothic text-lg">SPARTAN ZAIN-117</div>
              <div className="text-sm text-gray-400">UNSC-ID: 73829-19283-ZN</div>
              <div className="text-xs text-covenant-green mt-1">ACTIVE SESSION</div>
            </div>
            <button 
              className="ml-auto px-3 py-1 bg-forerunner-blue/20 hover:bg-forerunner-blue/40 text-forerunner-blue rounded text-sm"
              onMouseEnter={playHoverSound}
              onClick={playSelectSound}
            >
              EDIT
            </button>
          </div>
        </motion.div>
        
        {/* Display settings */}
        <motion.div 
          className="bg-forerunner-dark-blue/40 p-4 rounded-lg mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <h3 className="font-bank-gothic text-forerunner-blue mb-3">DISPLAY SETTINGS</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="flex items-center cursor-pointer">
                <span className="mr-3">Dark Mode</span>
                <div className="relative" onClick={() => { setDarkMode(!darkMode); playToggleSound(); }}>
                  <input type="checkbox" className="sr-only" checked={darkMode} onChange={() => {}} />
                  <div className="w-10 h-5 bg-forerunner-dark-blue rounded-full"></div>
                  <div className={`absolute w-4 h-4 bg-forerunner-blue rounded-full top-0.5 transform transition-all ${darkMode ? 'left-4' : 'left-1'}`}></div>
                </div>
              </label>
            </div>
            
            <div>
              <label className="block mb-2">Interface Opacity</label>
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={interfaceOpacity} 
                onChange={(e) => setInterfaceOpacity(parseInt(e.target.value))}
                className="w-full h-2 bg-forerunner-dark-blue rounded-full appearance-none"
              />
            </div>
            
            <div>
              <label className="block mb-2">Ambient Effects</label>
              <div className="grid grid-cols-3 gap-2">
                <button 
                  className={`p-2 ${ambientEffects === 'LOW' ? 'bg-forerunner-blue/30' : 'bg-forerunner-blue/10 hover:bg-forerunner-blue/30'} text-center rounded text-sm`}
                  onClick={() => handleAmbientEffectChange('LOW')}
                  onMouseEnter={playHoverSound}
                >
                  LOW
                </button>
                <button 
                  className={`p-2 ${ambientEffects === 'MEDIUM' ? 'bg-forerunner-blue/30' : 'bg-forerunner-blue/10 hover:bg-forerunner-blue/30'} text-center rounded text-sm`}
                  onClick={() => handleAmbientEffectChange('MEDIUM')}
                  onMouseEnter={playHoverSound}
                >
                  MEDIUM
                </button>
                <button 
                  className={`p-2 ${ambientEffects === 'HIGH' ? 'bg-forerunner-blue/30' : 'bg-forerunner-blue/10 hover:bg-forerunner-blue/30'} text-center rounded text-sm`}
                  onClick={() => handleAmbientEffectChange('HIGH')}
                  onMouseEnter={playHoverSound}
                >
                  HIGH
                </button>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Audio settings */}
        <motion.div 
          className="bg-forerunner-dark-blue/40 p-4 rounded-lg mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <h3 className="font-bank-gothic text-forerunner-blue mb-3">AUDIO SETTINGS</h3>
          
          <div className="space-y-4">
            {audioToggles.map(setting => (
              <div key={setting.id} className="flex items-center justify-between">
                <label className="flex items-center cursor-pointer">
                  <span className="mr-3">{setting.label}</span>
                  <div 
                    className="relative" 
                    onClick={() => toggleSetting(setting.id, 'audio')}
                  >
                    <input type="checkbox" className="sr-only" checked={setting.enabled} onChange={() => {}} />
                    <div className="w-10 h-5 bg-forerunner-dark-blue rounded-full"></div>
                    <div className={`absolute w-4 h-4 bg-forerunner-blue rounded-full top-0.5 transform transition-all ${setting.enabled ? 'left-4' : 'left-1'}`}></div>
                  </div>
                </label>
              </div>
            ))}
            
            <div>
              <label className="block mb-2">Audio Volume</label>
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={audioVolume} 
                onChange={(e) => setAudioVolume(parseInt(e.target.value))}
                className="w-full h-2 bg-forerunner-dark-blue rounded-full appearance-none"
              />
            </div>
          </div>
        </motion.div>
        
        {/* Notification settings */}
        <motion.div 
          className="bg-forerunner-dark-blue/40 p-4 rounded-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <h3 className="font-bank-gothic text-forerunner-blue mb-3">NOTIFICATION SETTINGS</h3>
          
          <div className="space-y-3">
            {notificationToggles.map(setting => (
              <div key={setting.id} className="flex items-center justify-between">
                <div>{setting.label}</div>
                <div 
                  className="relative cursor-pointer" 
                  onClick={() => toggleSetting(setting.id, 'notifications')}
                >
                  <input type="checkbox" className="sr-only" checked={setting.enabled} onChange={() => {}} />
                  <div className="w-10 h-5 bg-forerunner-dark-blue rounded-full"></div>
                  <div className={`absolute w-4 h-4 bg-forerunner-blue rounded-full top-0.5 transform transition-all ${setting.enabled ? 'left-4' : 'left-1'}`}></div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
