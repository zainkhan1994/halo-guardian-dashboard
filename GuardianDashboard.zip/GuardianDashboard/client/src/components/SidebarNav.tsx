import { useNavigation } from "@/context/NavigationContext";
import { useHaloAudio } from "@/hooks/useHaloAudio";
import { motion } from "framer-motion";

type MenuItem = {
  id: 'blueprint' | 'calendar' | 'tasks' | 'archives' | 'settings';
  icon: string;
  label: string;
};

const menuItems: MenuItem[] = [
  { id: 'blueprint', icon: 'fa-brain', label: 'Blueprint' },
  { id: 'calendar', icon: 'fa-calendar-alt', label: 'Calendar' },
  { id: 'tasks', icon: 'fa-bullseye', label: 'Tasks' },
  { id: 'archives', icon: 'fa-folder', label: 'Archives' },
  { id: 'settings', icon: 'fa-cog', label: 'Settings' }
];

export function SidebarNav() {
  const { activeSection, setActiveSection } = useNavigation();
  const { playHoverSound, playSelectSound } = useHaloAudio();
  
  const handleNavClick = (sectionId: MenuItem['id']) => {
    setActiveSection(sectionId);
    playSelectSound();
  };
  
  return (
    <div className="w-64 p-4 relative">
      <motion.div 
        className="holographic-panel h-full rounded-lg p-3 flex flex-col"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="uppercase font-bank-gothic text-forerunner-blue text-xs mb-4 tracking-wider pl-2">Navigation</div>
        
        {/* Navigation menu */}
        <nav className="flex-1">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.id}>
                <button 
                  className={`menu-item w-full flex items-center space-x-3 px-4 py-3 rounded-md text-left ${activeSection === item.id ? 'active' : ''}`}
                  onClick={() => handleNavClick(item.id)}
                  onMouseEnter={playHoverSound}
                >
                  <i className={`fas ${item.icon} text-forerunner-blue`}></i>
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* Status indicator */}
        <div className="pt-4 mt-auto">
          <div className="flex items-center px-4 py-2 text-sm">
            <div className="w-2 h-2 rounded-full bg-covenant-green animate-pulse mr-2"></div>
            <span className="text-xs opacity-70">UNSC NETWORK ACTIVE</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
