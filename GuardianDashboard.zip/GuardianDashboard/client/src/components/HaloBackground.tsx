import { motion } from "framer-motion";

export function HaloBackground() {
  return (
    <>
      {/* Background image with overlay for Guardian map */}
      <div 
        className="fixed inset-0 w-full h-full z-0" 
        style={{ 
          backgroundColor: '#0a1423', /* Halo-themed dark blue background as fallback */
          backgroundImage: `radial-gradient(circle at center, #173252 0%, #0a1423 70%)`,
          backgroundPosition: 'center', 
          filter: 'brightness(0.7) saturate(1.2)'
        }}
      >
        {/* Forerunner patterns - simulating Guardian map texture */}
        <div className="absolute inset-0 opacity-20" 
          style={{
            backgroundImage: `repeating-linear-gradient(0deg, #00a3ff, transparent 2px, transparent 10px), 
                              repeating-linear-gradient(90deg, #00a3ff, transparent 2px, transparent 10px)`,
            backgroundSize: '50px 50px'
          }}>
        </div>
      </div>
      
      {/* Animated fog overlay */}
      <motion.div 
        className="fog-overlay fixed inset-0 z-10 opacity-40"
        animate={{
          x: ["0%", "3%", "0%", "-3%", "0%"],
          y: ["0%", "-2%", "0%", "2%", "0%"]
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear"
        }}
      />
    </>
  );
}
