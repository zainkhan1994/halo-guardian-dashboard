import { useNavigation } from "@/context/NavigationContext";
import { BlueprintSection } from "./blueprint/BlueprintSection";
import { CalendarSection } from "./calendar/CalendarSection";
import { TasksSection } from "./tasks/TasksSection";
import { ArchivesSection } from "./archives/ArchivesSection";
import { SettingsSection } from "./settings/SettingsSection";

export function MainContent() {
  const { activeSection } = useNavigation();
  
  return (
    <div className="flex-1 p-4 relative">
      {activeSection === 'blueprint' && <BlueprintSection />}
      {activeSection === 'calendar' && <CalendarSection />}
      {activeSection === 'tasks' && <TasksSection />}
      {activeSection === 'archives' && <ArchivesSection />}
      {activeSection === 'settings' && <SettingsSection />}
    </div>
  );
}
