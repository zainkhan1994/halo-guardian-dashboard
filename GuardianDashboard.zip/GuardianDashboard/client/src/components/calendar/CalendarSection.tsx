import { motion } from "framer-motion";
import { useState } from "react";

// Calendar data for demonstration
const calendarData = {
  month: "JUNE",
  year: 2023,
  days: [
    { day: 1, events: [
      { time: "0800", title: "Meeting", type: "warning" },
      { time: "1400", title: "Training", type: "success" }
    ]},
    { day: 2, events: [
      { time: "1100", title: "Research", type: "primary" }
    ]},
    { day: 3, events: [] },
    { day: 4, events: [
      { time: "0900", title: "Briefing", type: "warning" }
    ]},
    { day: 5, events: [
      { time: "1000", title: "Mission", type: "primary" },
      { time: "1600", title: "Debrief", type: "success" }
    ], isCurrentDay: true },
    { day: 6, events: [] },
    { day: 7, events: [
      { time: "", title: "REST DAY", type: "purple" }
    ]},
    { day: 8, events: [
      { time: "1300", title: "Analysis", type: "primary" }
    ]},
    { day: 9, events: [] },
    { day: 10, events: [
      { time: "0800", title: "Deployment", type: "warning" }
    ]},
    { day: 11, events: [] },
    { day: 12, events: [
      { time: "1500", title: "Review", type: "success" }
    ]},
    { day: 13, events: [] },
    { day: 14, events: [
      { time: "", title: "REST DAY", type: "purple" }
    ]},
  ]
};

// Map type to CSS classes
const eventTypeClasses = {
  primary: "bg-forerunner-blue/20 text-forerunner-blue",
  success: "bg-covenant-green/20 text-covenant-green",
  warning: "bg-warning/20 text-warning",
  purple: "bg-covenant-purple/20 text-covenant-purple"
};

export function CalendarSection() {
  const [currentMonth, setCurrentMonth] = useState(calendarData);
  
  return (
    <motion.div 
      className="holographic-panel rounded-lg p-5 h-full overflow-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-xl font-bank-gothic text-forerunner-blue border-b border-forerunner-blue/40 pb-2 mb-6 flex items-center">
        <i className="fas fa-calendar-alt mr-3"></i>
        <span>TACTICAL CALENDAR</span>
      </div>
      
      <div className="flex mb-4 space-x-2">
        <button className="px-4 py-2 bg-forerunner-blue/20 hover:bg-forerunner-blue/30 rounded font-bank-gothic text-sm">
          TODAY
        </button>
        <button className="px-3 py-2 bg-forerunner-dark-blue/60 hover:bg-forerunner-dark-blue rounded text-sm">
          <i className="fas fa-chevron-left"></i>
        </button>
        <button className="px-3 py-2 bg-forerunner-dark-blue/60 hover:bg-forerunner-dark-blue rounded text-sm">
          <i className="fas fa-chevron-right"></i>
        </button>
        <div className="ml-auto flex items-center font-bank-gothic text-forerunner-blue">
          {currentMonth.month} {currentMonth.year}
        </div>
      </div>
      
      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-2 h-[calc(100%-120px)] overflow-auto pb-4">
        {/* Day headers */}
        <div className="text-center text-xs text-gray-400 font-bank-gothic py-2">MON</div>
        <div className="text-center text-xs text-gray-400 font-bank-gothic py-2">TUE</div>
        <div className="text-center text-xs text-gray-400 font-bank-gothic py-2">WED</div>
        <div className="text-center text-xs text-gray-400 font-bank-gothic py-2">THU</div>
        <div className="text-center text-xs text-gray-400 font-bank-gothic py-2">FRI</div>
        <div className="text-center text-xs text-gray-400 font-bank-gothic py-2">SAT</div>
        <div className="text-center text-xs text-gray-400 font-bank-gothic py-2">SUN</div>
        
        {/* Calendar days */}
        {currentMonth.days.map((day, index) => (
          <motion.div 
            key={index}
            className={`${day.isCurrentDay ? 'bg-forerunner-blue/30 shadow-holo' : 'bg-forerunner-dark-blue/40 hover:shadow-holo'} rounded-md p-1 h-24 overflow-hidden transition-all`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.03 }}
          >
            <div className={`text-right text-xs mb-1 ${day.isCurrentDay ? 'font-bold' : ''}`}>{day.day}</div>
            {day.events.map((event, eventIndex) => (
              <div 
                key={eventIndex} 
                className={`text-xs p-1 ${eventIndex !== day.events.length - 1 ? 'mb-1' : ''} ${eventTypeClasses[event.type as keyof typeof eventTypeClasses]} rounded`}
              >
                {event.time && `${event.time} - `}{event.title}
              </div>
            ))}
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
