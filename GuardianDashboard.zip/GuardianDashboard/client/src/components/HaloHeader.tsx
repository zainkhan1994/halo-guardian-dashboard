import { useDateTime } from "@/hooks/useDateTime";

export function HaloHeader() {
  const { time, date } = useDateTime();
  
  return (
    <header className="px-6 py-4 flex justify-between items-center">
      <div className="flex items-center">
        <div className="w-12 h-12 rounded-full bg-forerunner-dark-blue border-2 border-forerunner-blue flex items-center justify-center shadow-holo animate-pulse-slow">
          <i className="fas fa-shield-alt text-forerunner-blue text-xl"></i>
        </div>
        <div className="ml-4 font-bank-gothic tracking-wider">
          <h1 className="text-forerunner-blue text-xl">ZAIN <span className="text-white opacity-90">|</span> CORTANA OS</h1>
          <div className="text-xs text-gray-400">UNSC-TERMINAL // ACTIVE-SESSION</div>
        </div>
      </div>
      
      <div className="flex space-x-4">
        <div className="text-sm opacity-70 animate-pulse-slow">
          <div className="font-bank-gothic">LIVE FEED</div>
          <div className="text-covenant-green">GUARDIAN.MAP // SECURE</div>
        </div>
        <div className="text-sm opacity-70">
          <div className="font-bank-gothic">{time}</div>
          <div className="text-covenant-green">{date}</div>
        </div>
      </div>
    </header>
  );
}
