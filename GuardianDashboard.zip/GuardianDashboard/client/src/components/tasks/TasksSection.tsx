import { motion } from "framer-motion";
import { useState } from "react";
import { useHaloAudio } from "@/hooks/useHaloAudio";

interface Task {
  id: number;
  title: string;
  dueText: string;
  tag: {
    text: string;
    type: 'urgent' | 'research' | 'completed' | 'training' | 'security';
  };
  completed: boolean;
}

// Tag type to CSS classes mapping
const tagStyles = {
  urgent: "bg-warning/20 text-warning",
  research: "bg-forerunner-blue/20 text-forerunner-blue",
  completed: "bg-covenant-green/20 text-covenant-green",
  training: "bg-covenant-purple/20 text-covenant-purple",
  security: "bg-forerunner-blue/20 text-forerunner-blue",
};

// Initial tasks data
const initialTasks: Task[] = [
  {
    id: 1,
    title: "Complete Guardian surveillance report",
    dueText: "Due today at 1800 hours",
    tag: { text: "URGENT", type: "urgent" },
    completed: false
  },
  {
    id: 2,
    title: "Analyze Forerunner tech samples",
    dueText: "Due tomorrow at 1400 hours",
    tag: { text: "RESEARCH", type: "research" },
    completed: false
  },
  {
    id: 3,
    title: "Prepare team briefing",
    dueText: "Completed yesterday",
    tag: { text: "COMPLETED", type: "completed" },
    completed: true
  },
  {
    id: 4,
    title: "Schedule weapons training",
    dueText: "Due in 3 days",
    tag: { text: "TRAINING", type: "training" },
    completed: false
  },
  {
    id: 5,
    title: "Update security protocols",
    dueText: "Due in 2 days",
    tag: { text: "SECURITY", type: "security" },
    completed: false
  }
];

type FilterType = 'all' | 'active' | 'completed';

export function TasksSection() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const { playToggleSound, playHoverSound, playSelectSound } = useHaloAudio();
  
  const toggleTaskStatus = (taskId: number) => {
    playToggleSound();
    setTasks(tasks.map(task => 
      task.id === taskId 
        ? { 
            ...task, 
            completed: !task.completed,
            tag: !task.completed 
              ? { text: "COMPLETED", type: "completed" }
              : { ...task.tag } // Restore original tag if uncompleting
          } 
        : task
    ));
  };
  
  const addNewTask = () => {
    if (newTaskTitle.trim() === "") return;
    
    playSelectSound();
    const newTask: Task = {
      id: Date.now(),
      title: newTaskTitle,
      dueText: "Due soon",
      tag: { text: "ACTIVE", type: "research" },
      completed: false
    };
    
    setTasks([...tasks, newTask]);
    setNewTaskTitle("");
  };
  
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      addNewTask();
    }
  };
  
  const filteredTasks = tasks.filter(task => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'active') return !task.completed;
    if (activeFilter === 'completed') return task.completed;
    return true;
  });
  
  // Calculate mission completion percentage
  const completionPercentage = Math.round((tasks.filter(t => t.completed).length / tasks.length) * 100);
  
  return (
    <motion.div 
      className="holographic-panel rounded-lg p-5 h-full overflow-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-xl font-bank-gothic text-forerunner-blue border-b border-forerunner-blue/40 pb-2 mb-6 flex items-center">
        <i className="fas fa-bullseye mr-3"></i>
        <span>MISSION OBJECTIVES</span>
      </div>
      
      <div className="flex items-center mb-4">
        <div className="flex-1">
          <input 
            type="text" 
            placeholder="Add new mission objective..." 
            className="w-full bg-forerunner-dark-blue/40 border border-forerunner-blue/30 p-3 rounded text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-forerunner-blue/50"
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            onKeyPress={handleKeyPress}
          />
        </div>
        <button 
          className="ml-2 p-3 bg-forerunner-blue/20 hover:bg-forerunner-blue/40 rounded text-forerunner-blue"
          onClick={addNewTask}
          onMouseEnter={playHoverSound}
        >
          <i className="fas fa-plus"></i>
        </button>
      </div>
      
      <div className="h-[calc(100%-140px)] overflow-auto pb-4">
        {/* Task filter tabs */}
        <div className="flex space-x-2 mb-4">
          <button 
            className={`px-4 py-1 rounded text-sm font-bank-gothic ${activeFilter === 'all' ? 'bg-forerunner-blue/40' : 'bg-forerunner-dark-blue/40 hover:bg-forerunner-dark-blue/60'}`}
            onClick={() => setActiveFilter('all')}
            onMouseEnter={playHoverSound}
          >
            ALL
          </button>
          <button 
            className={`px-4 py-1 rounded text-sm font-bank-gothic ${activeFilter === 'active' ? 'bg-forerunner-blue/40' : 'bg-forerunner-dark-blue/40 hover:bg-forerunner-dark-blue/60'}`}
            onClick={() => setActiveFilter('active')}
            onMouseEnter={playHoverSound}
          >
            ACTIVE
          </button>
          <button 
            className={`px-4 py-1 rounded text-sm font-bank-gothic ${activeFilter === 'completed' ? 'bg-forerunner-blue/40' : 'bg-forerunner-dark-blue/40 hover:bg-forerunner-dark-blue/60'}`}
            onClick={() => setActiveFilter('completed')}
            onMouseEnter={playHoverSound}
          >
            COMPLETED
          </button>
        </div>
        
        {/* Tasks list */}
        <div className="space-y-2">
          {filteredTasks.map((task) => (
            <motion.div 
              key={task.id}
              className="task-item flex items-center p-3 bg-forerunner-dark-blue/40 rounded transition-all"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div 
                className={`w-5 h-5 border-2 ${task.completed ? 'border-covenant-green bg-covenant-green/20' : 'border-forerunner-blue hover:bg-forerunner-blue/20'} rounded-sm flex items-center justify-center mr-3 cursor-pointer`}
                onClick={() => toggleTaskStatus(task.id)}
              >
                <i className={`fas fa-check text-${task.completed ? 'covenant-green' : 'forerunner-blue'} text-xs ${!task.completed && 'opacity-0'}`}></i>
              </div>
              <div className="flex-1">
                <div className={`font-medium ${task.completed ? 'line-through text-gray-400' : ''}`}>{task.title}</div>
                <div className="text-xs text-gray-400">{task.dueText}</div>
              </div>
              <div className={`text-xs ${tagStyles[task.tag.type]} px-2 py-1 rounded-full mr-2`}>
                {task.tag.text}
              </div>
              <button className="text-gray-400 hover:text-forerunner-blue">
                <i className="fas fa-ellipsis-v"></i>
              </button>
            </motion.div>
          ))}
          
          {filteredTasks.length === 0 && (
            <div className="text-center py-8 text-gray-400">
              <i className="fas fa-clipboard-check text-3xl mb-2"></i>
              <p>No {activeFilter !== 'all' ? activeFilter : ''} tasks found</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="border-t border-forerunner-blue/30 pt-3 mt-auto">
        <div className="flex justify-between text-sm">
          <span>Mission Completion</span>
          <span className="text-forerunner-blue">{completionPercentage}%</span>
        </div>
        <div className="h-1.5 bg-forerunner-dark-blue rounded-full overflow-hidden mt-1">
          <motion.div 
            className="h-full bg-forerunner-blue rounded-full" 
            initial={{ width: 0 }}
            animate={{ width: `${completionPercentage}%` }}
            transition={{ duration: 1 }}
          ></motion.div>
        </div>
      </div>
    </motion.div>
  );
}
