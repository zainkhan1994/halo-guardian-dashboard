import { motion } from "framer-motion";
import { useState } from "react";
import { useHaloAudio } from "@/hooks/useHaloAudio";

interface Folder {
  id: string;
  name: string;
  documentCount: number;
  lastUpdate: string;
}

interface File {
  id: string;
  name: string;
  icon: string;
  modified: string;
  size: string;
}

const folders: Folder[] = [
  {
    id: 'mission-reports',
    name: 'MISSION REPORTS',
    documentCount: 24,
    lastUpdate: 'Updated 3 days ago'
  },
  {
    id: 'research-data',
    name: 'RESEARCH DATA',
    documentCount: 48,
    lastUpdate: 'Updated 1 day ago'
  },
  {
    id: 'personnel-files',
    name: 'PERSONNEL FILES',
    documentCount: 12,
    lastUpdate: 'Updated 1 week ago'
  },
  {
    id: 'tactical-maps',
    name: 'TACTICAL MAPS',
    documentCount: 8,
    lastUpdate: 'Updated 2 days ago'
  }
];

const recentFiles: File[] = [
  {
    id: 'file1',
    name: 'Guardian_Recon_Report_06052023.txt',
    icon: 'fa-file-alt',
    modified: 'Modified today at 0945 hours',
    size: '2.4 MB'
  },
  {
    id: 'file2',
    name: 'Forerunner_Tech_Scan_053.png',
    icon: 'fa-image',
    modified: 'Modified yesterday at 1621 hours',
    size: '8.1 MB'
  },
  {
    id: 'file3',
    name: 'Enemy_Movement_Analysis.pptx',
    icon: 'fa-chart-bar',
    modified: 'Modified 3 days ago',
    size: '5.7 MB'
  }
];

export function ArchivesSection() {
  const [searchTerm, setSearchTerm] = useState("");
  const { playHoverSound, playSelectSound } = useHaloAudio();
  
  const handleFolderClick = (folderId: string) => {
    playSelectSound();
    console.log(`Opening folder: ${folderId}`);
  };
  
  const handleFileClick = (fileId: string) => {
    playSelectSound();
    console.log(`Opening file: ${fileId}`);
  };
  
  return (
    <motion.div 
      className="holographic-panel rounded-lg p-5 h-full overflow-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-xl font-bank-gothic text-forerunner-blue border-b border-forerunner-blue/40 pb-2 mb-6 flex items-center">
        <i className="fas fa-folder mr-3"></i>
        <span>ARCHIVE RECORDS</span>
      </div>
      
      <div className="relative mb-4">
        <input 
          type="text" 
          placeholder="Search archives..." 
          className="w-full bg-forerunner-dark-blue/40 border border-forerunner-blue/30 p-3 pl-10 rounded text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-forerunner-blue/50"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
      </div>
      
      <div className="h-[calc(100%-110px)] overflow-auto pb-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Archive folders */}
          {folders.map((folder, index) => (
            <motion.div
              key={folder.id}
              className="bg-forerunner-dark-blue/40 p-4 rounded-lg hover:shadow-holo transition-all cursor-pointer"
              onClick={() => handleFolderClick(folder.id)}
              onMouseEnter={playHoverSound}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-forerunner-blue/20 flex items-center justify-center mr-3">
                  <i className="fas fa-folder text-forerunner-blue"></i>
                </div>
                <div>
                  <div className="font-bank-gothic">{folder.name}</div>
                  <div className="text-xs text-gray-400">{folder.documentCount} documents - {folder.lastUpdate}</div>
                </div>
              </div>
            </motion.div>
          ))}
          
          {/* Recent files */}
          <div className="col-span-1 md:col-span-2 mt-4">
            <h3 className="font-bank-gothic text-forerunner-blue mb-3">RECENT FILES</h3>
            
            <div className="space-y-2">
              {recentFiles.map((file, index) => (
                <motion.div
                  key={file.id}
                  className="flex items-center p-3 bg-forerunner-dark-blue/40 rounded hover:shadow-holo transition-all cursor-pointer"
                  onClick={() => handleFileClick(file.id)}
                  onMouseEnter={playHoverSound}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.5 + (index * 0.1) }}
                >
                  <div className="w-8 h-8 rounded-full bg-forerunner-blue/20 flex items-center justify-center mr-3">
                    <i className={`fas ${file.icon} text-forerunner-blue`}></i>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{file.name}</div>
                    <div className="text-xs text-gray-400">{file.modified}</div>
                  </div>
                  <div className="text-xs text-gray-400">{file.size}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
