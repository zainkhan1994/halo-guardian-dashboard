import { motion } from "framer-motion";

const statCards = [
  {
    id: 'health',
    title: 'HEALTH',
    icon: 'fa-heartbeat',
    status: 'OPTIMAL',
    statusColor: 'text-covenant-green',
    statusBg: 'bg-covenant-green/20',
    items: [
      { name: 'Sleep Quality', value: '92%', color: 'bg-covenant-green', width: '92%' },
      { name: 'Hydration', value: '85%', color: 'bg-covenant-green', width: '85%' },
      { name: 'Activity', value: '63%', color: 'bg-forerunner-blue', width: '63%' }
    ]
  },
  {
    id: 'projects',
    title: 'PROJECTS',
    icon: 'fa-rocket',
    status: 'IN PROGRESS',
    statusColor: 'text-forerunner-blue',
    statusBg: 'bg-forerunner-blue/20',
    projects: [
      { name: 'Covenant Shield Research', dueText: 'Due in 3 days', progress: '76%', color: 'text-forerunner-blue' },
      { name: 'Guardian Mapping', dueText: 'Due in 5 days', progress: '42%', color: 'text-forerunner-blue' },
      { name: 'Forerunner Tech Analysis', dueText: 'Due in 1 day', progress: '89%', color: 'text-warning' }
    ]
  },
  {
    id: 'finance',
    title: 'FINANCE',
    icon: 'fa-chart-line',
    status: 'STABLE',
    statusColor: 'text-covenant-green',
    statusBg: 'bg-covenant-green/20',
    budget: {
      total: '₡ 2,500',
      remaining: '₡ 1,785',
      usagePercent: '29%',
      barWidth: '29%',
      barColor: 'bg-covenant-green'
    }
  },
  {
    id: 'research',
    title: 'RESEARCH',
    icon: 'fa-flask',
    status: 'ONGOING',
    statusColor: 'text-forerunner-blue',
    statusBg: 'bg-forerunner-blue/20',
    topics: [
      { name: 'Forerunner Architecture', icon: 'fa-book-open', iconColor: 'text-covenant-green', updated: 'Updated 2h ago' },
      { name: 'Energy Shield Tech', icon: 'fa-microscope', iconColor: 'text-forerunner-blue', updated: 'Updated 1d ago' },
      { name: 'Slipspace Physics', icon: 'fa-atom', iconColor: 'text-warning', updated: 'Updated 3d ago' }
    ]
  }
];

export function BlueprintSection() {
  return (
    <motion.div 
      className="holographic-panel rounded-lg p-5 h-full overflow-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-xl font-bank-gothic text-forerunner-blue border-b border-forerunner-blue/40 pb-2 mb-6 flex items-center">
        <i className="fas fa-brain mr-3"></i>
        <span>BLUEPRINT OVERVIEW</span>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-[calc(100%-60px)] overflow-auto pb-4">
        {/* Health card */}
        <motion.div 
          className="holographic-panel rounded-lg p-4 hover:shadow-holo transition-all"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-forerunner-blue/20 flex items-center justify-center mr-2">
                <i className="fas fa-heartbeat text-forerunner-blue"></i>
              </div>
              <h3 className="font-bank-gothic">HEALTH</h3>
            </div>
            <span className="text-xs bg-covenant-green/20 text-covenant-green px-2 py-1 rounded">OPTIMAL</span>
          </div>
          
          <div className="space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>Sleep Quality</span>
                <span className="text-covenant-green">92%</span>
              </div>
              <div className="h-1.5 bg-forerunner-dark-blue rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-covenant-green rounded-full" 
                  initial={{ width: 0 }}
                  animate={{ width: '92%' }}
                  transition={{ duration: 1, delay: 0.5 }}
                ></motion.div>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>Hydration</span>
                <span className="text-covenant-green">85%</span>
              </div>
              <div className="h-1.5 bg-forerunner-dark-blue rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-covenant-green rounded-full" 
                  initial={{ width: 0 }}
                  animate={{ width: '85%' }}
                  transition={{ duration: 1, delay: 0.7 }}
                ></motion.div>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>Activity</span>
                <span className="text-forerunner-blue">63%</span>
              </div>
              <div className="h-1.5 bg-forerunner-dark-blue rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-forerunner-blue rounded-full" 
                  initial={{ width: 0 }}
                  animate={{ width: '63%' }}
                  transition={{ duration: 1, delay: 0.9 }}
                ></motion.div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Projects card */}
        <motion.div 
          className="holographic-panel rounded-lg p-4 hover:shadow-holo transition-all"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-forerunner-blue/20 flex items-center justify-center mr-2">
                <i className="fas fa-rocket text-forerunner-blue"></i>
              </div>
              <h3 className="font-bank-gothic">PROJECTS</h3>
            </div>
            <span className="text-xs bg-forerunner-blue/20 text-forerunner-blue px-2 py-1 rounded">IN PROGRESS</span>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-2 rounded bg-forerunner-dark-blue/40">
              <div>
                <div className="font-semibold">Covenant Shield Research</div>
                <div className="text-xs text-gray-400">Due in 3 days</div>
              </div>
              <div className="text-sm">
                <span className="text-forerunner-blue">76%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-2 rounded bg-forerunner-dark-blue/40">
              <div>
                <div className="font-semibold">Guardian Mapping</div>
                <div className="text-xs text-gray-400">Due in 5 days</div>
              </div>
              <div className="text-sm">
                <span className="text-forerunner-blue">42%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-2 rounded bg-forerunner-dark-blue/40">
              <div>
                <div className="font-semibold">Forerunner Tech Analysis</div>
                <div className="text-xs text-gray-400">Due in 1 day</div>
              </div>
              <div className="text-sm">
                <span className="text-warning">89%</span>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Finance card */}
        <motion.div 
          className="holographic-panel rounded-lg p-4 hover:shadow-holo transition-all"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-forerunner-blue/20 flex items-center justify-center mr-2">
                <i className="fas fa-chart-line text-forerunner-blue"></i>
              </div>
              <h3 className="font-bank-gothic">FINANCE</h3>
            </div>
            <span className="text-xs bg-covenant-green/20 text-covenant-green px-2 py-1 rounded">STABLE</span>
          </div>
          
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-forerunner-dark-blue/40 p-3 rounded">
                <div className="text-xs text-gray-400">Monthly Budget</div>
                <div className="text-lg font-semibold">₡ 2,500</div>
              </div>
              <div className="bg-forerunner-dark-blue/40 p-3 rounded">
                <div className="text-xs text-gray-400">Remaining</div>
                <div className="text-lg font-semibold text-covenant-green">₡ 1,785</div>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>Budget Usage</span>
                <span className="text-covenant-green">29%</span>
              </div>
              <div className="h-1.5 bg-forerunner-dark-blue rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-covenant-green rounded-full" 
                  initial={{ width: 0 }}
                  animate={{ width: '29%' }}
                  transition={{ duration: 1, delay: 0.5 }}
                ></motion.div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Research card */}
        <motion.div 
          className="holographic-panel rounded-lg p-4 hover:shadow-holo transition-all"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.4 }}
        >
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-forerunner-blue/20 flex items-center justify-center mr-2">
                <i className="fas fa-flask text-forerunner-blue"></i>
              </div>
              <h3 className="font-bank-gothic">RESEARCH</h3>
            </div>
            <span className="text-xs bg-forerunner-blue/20 text-forerunner-blue px-2 py-1 rounded">ONGOING</span>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-2 rounded bg-forerunner-dark-blue/40">
              <div className="flex items-center">
                <i className="fas fa-book-open text-covenant-green mr-2"></i>
                <div>Forerunner Architecture</div>
              </div>
              <div className="text-xs text-gray-400">Updated 2h ago</div>
            </div>
            
            <div className="flex items-center justify-between p-2 rounded bg-forerunner-dark-blue/40">
              <div className="flex items-center">
                <i className="fas fa-microscope text-forerunner-blue mr-2"></i>
                <div>Energy Shield Tech</div>
              </div>
              <div className="text-xs text-gray-400">Updated 1d ago</div>
            </div>
            
            <div className="flex items-center justify-between p-2 rounded bg-forerunner-dark-blue/40">
              <div className="flex items-center">
                <i className="fas fa-atom text-warning mr-2"></i>
                <div>Slipspace Physics</div>
              </div>
              <div className="text-xs text-gray-400">Updated 3d ago</div>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
