import { HaloBackground } from "@/components/HaloBackground";
import { SidebarNav } from "@/components/SidebarNav";
import { MainContent } from "@/components/MainContent";
import { HaloHeader } from "@/components/HaloHeader";
import { useHaloAudio } from "@/hooks/useHaloAudio";

export default function Home() {
  const { isMuted, toggleMute } = useHaloAudio();
  
  return (
    <div className="font-eurostile text-white overflow-hidden h-screen relative">
      {/* Background with fog overlay */}
      <HaloBackground />
      
      {/* Scan line effect */}
      <div className="scan-line z-20"></div>
      
      {/* Main container */}
      <div className="relative z-30 h-full overflow-hidden flex flex-col">
        {/* Header */}
        <HaloHeader />
        
        {/* Main content area */}
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar navigation */}
          <SidebarNav />
          
          {/* Main content panels */}
          <MainContent />
        </div>
      </div>
      
      {/* Audio controls */}
      <div className="fixed bottom-4 right-4 bg-forerunner-dark-blue/80 p-2 rounded-full z-50 flex items-center space-x-2">
        <button 
          onClick={toggleMute}
          className="w-8 h-8 flex items-center justify-center text-forerunner-blue hover:text-white transition-colors"
        >
          <i className={`fas ${isMuted ? 'fa-volume-mute' : 'fa-volume-up'}`}></i>
        </button>
      </div>
    </div>
  );
}
